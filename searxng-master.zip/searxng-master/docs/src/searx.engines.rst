.. _load_engines:

============
Load Engines
============

.. automodule:: searx.engines
  :members:
