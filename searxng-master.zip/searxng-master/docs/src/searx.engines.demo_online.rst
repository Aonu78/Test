.. _demo online engine:

==================
Demo Online Engine
==================

.. automodule:: searx.engines.demo_online
  :members:

